$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "964efcd7-7425-4460-bd43-21fb5f01fe20",
    "feature": "Login feature",
    "scenario": "Login normally",
    "start": 1621501293083,
    "group": 19,
    "content": "",
    "tags": "",
    "end": 1621501307238,
    "className": "failed"
  },
  {
    "id": "67a44ba0-7794-4198-a5dd-a83973ddddc2",
    "feature": "Login feature",
    "scenario": "Login Page Title",
    "start": 1621501293079,
    "group": 18,
    "content": "",
    "tags": "@skip,",
    "end": 1621501298241,
    "className": "skipped"
  },
  {
    "id": "bc49200b-8b84-4bca-b050-8541d8b095a0",
    "feature": "Login feature",
    "scenario": "Check homepage title",
    "start": 1621501293085,
    "group": 17,
    "content": "",
    "tags": "",
    "end": 1621501311900,
    "className": "passed"
  },
  {
    "id": "dda06013-1ed3-4391-b63d-b0ccb3b46e3b",
    "feature": "Login feature",
    "scenario": "Check All menu options",
    "start": 1621501293087,
    "group": 16,
    "content": "",
    "tags": "",
    "end": 1621501311405,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 16,
    "content": "Thread[TestNG-PoolService-0,5,main]"
  },
  {
    "id": 17,
    "content": "Thread[TestNG-PoolService-1,5,main]"
  },
  {
    "id": 18,
    "content": "Thread[TestNG-PoolService-2,5,main]"
  },
  {
    "id": 19,
    "content": "Thread[TestNG-PoolService-3,5,main]"
  }
]);
});