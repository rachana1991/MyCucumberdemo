package Pages;



import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Homepage {

private WebDriver driver;
	
	//By locators
	
	private By pincode = By.id("pincode");
	private By proceed = By.id("zip-check");
	private By menubar = By.xpath("//ul[@class='site-nav']/li");

	//constructor
	public Homepage (WebDriver driver) {
		this.driver= driver;
	}
	
	//page actions - features
	
	
	public void enter_pincode(String pin) {
		driver.findElement(pincode).sendKeys(pin);
	}
	
	public void proceed() {
		driver.findElement(proceed).click();
	}
	
	public int getMenuCount() {
		int size = driver.findElements(menubar).size();
		System.out.println("The actual size is: "+size);
		return size;
	}
		public List<String> getMenuList() {
			
			List<String> menuListString = new ArrayList<>();
			List<WebElement> menulist = driver.findElements(menubar);
			for(WebElement e:menulist) {
				String text = e.getText();
				System.out.println(text);
				menuListString.add(text);
			}
			return menuListString;
		}
}