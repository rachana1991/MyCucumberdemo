package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login {

	private WebDriver driver;
	
	
	//By locators
	private By email = By.id("customer_email");
	private By pswd = By.id("customer_password");
	private By signin = By.id("login_submit_btn");
	private By pincode = By.id("pincode");
	private By proceed = By.id("zip-check");
	private By pincodeclose = By.id("zip-skip");
	
	
	
	//constructor
	public Login (WebDriver driver) {
		this.driver= driver;
	}
	
	//page actions - features
	public String getpageTitle() {
		return driver.getTitle();
	}
	
	public void enter_pincode(String pin) {
		driver.findElement(pincode).sendKeys(pin);
	}
	
	public void proceed() {
		driver.findElement(proceed).click();
	}
	
	
	public void enter_username(String username) {
		driver.findElement(email).sendKeys(username);
	}
	
	public void enter_password(String password) {
		driver.findElement(pswd).sendKeys(password);
	}
	
	public void click_login() {
		driver.findElement(signin).click();
	}
	
	public String gethometitle() {
		
		return driver.getTitle();
	}
	
public void closepincode() {
		
	driver.findElement(pincodeclose).click();
	}
	
}
