package Parallel;

import org.junit.Assert;

import Factory.DriverFactory;
import Pages.Login;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	private static String title;
	private Login login = new Login(DriverFactory.getDriver());

	@Given("User is on login page")
	public void user_is_on_login_page() {
		DriverFactory.getDriver().get("https://itcstore.in/account/login");
	}

	@Then("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		 title= login.getpageTitle();
		 System.out.println("The actual page title is: "+ title);
	   
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String expectedtitle) {
		System.out.println("The expected title should be : "+expectedtitle);
		 Assert.assertTrue(title.contains(expectedtitle));
	    
	}
	
	@When("user closes pincode")
	public void user_closes_pincode() {
		// login.enter_pincode(pincode);
		// login.proceed();
		login.closepincode();
	   
	}
	

	@And("user enters username {string}")
	public void user_enters_username(String username) {
	   login.enter_username(username);
	}

	@When("user enters passsword {string}")
	public void user_enters_passsword(String password) {
			   login.enter_password(password);
			}
	
	@When("user clicks on login button")
	public void user_clicks_on_login_button() {
	    login.click_login();
	}
}
