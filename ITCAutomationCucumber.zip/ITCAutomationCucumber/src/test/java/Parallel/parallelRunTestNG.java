package Parallel;


import org.junit.runner.RunWith;
import org.testng.annotations.DataProvider;

import io.cucumber.junit.Cucumber;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/test/resources/Parallel"},
		glue = {"Parallel"},
		plugin= {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				"pretty",
				"timeline:test-output-thread/",
				"rerun:target/RerunFailed.txt"}
	//,	tags = "not @Skip"
		)

public class parallelRunTestNG extends AbstractTestNGCucumberTests{
	
	@Override
	@DataProvider(parallel= true)
	public Object[][] scenarios(){
		return super.scenarios();
		
		
	}

}
