package stepDefinitions;

import java.util.List;

import org.junit.Assert;

import Factory.DriverFactory;
import Pages.Homepage;
import Pages.Login;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomepageSteps {

	
	private Homepage homepage = new Homepage(DriverFactory.getDriver());
	
	@Given("User is on homepage")
	public void user_is_on_homepage() {
		DriverFactory.getDriver().get("https://itcstore.in");
	}

	@When("user enters pincode {string}")
	public void user_enters_pincode(String pinn) {
		homepage.enter_pincode(pinn);
		
	}

	@When("clicks proceed")
	public void clicks_proceed() {
		homepage.proceed();
	}
	
	@When("user gets the menu options")
	public void user_gets_the_menu_options(DataTable menuTable) {
		List<String> expectedmenulist= menuTable.asList();
	   List<String> actualmenulist= homepage.getMenuList();
	   
	   Assert.assertTrue(expectedmenulist.containsAll(actualmenulist));
	}

	@Then("the menu options count should be {int}")
	public void the_menu_options_count_should_be(Integer expectedMenuCount) {
	    Assert.assertTrue(homepage.getMenuCount()== expectedMenuCount);
	}
}
